RECOVERAI - CURRENT PROJECT IMAGE RECOVERY FILES

These are complete replacement files adapted to the current SQLAlchemy/FastAPI project.

1. Replace:
backend/app/services/image_recovery_service.py
with the supplied image_recovery_service.py

2. Replace:
backend/app/services/universal_recovery_service.py
with the supplied universal_recovery_service.py

3. Install the image-recovery dependency inside the backend virtual environment:
pip install simple-lama-inpainting

The image branch uses OpenCV corruption-mask detection + LaMa inpainting.
The recovered pixels are explicitly classified as:
AI-INFERRED RECONSTRUCTION
INFERRED — NOT VERIFIED ORIGINAL DATA

No existing folder structure is changed.
