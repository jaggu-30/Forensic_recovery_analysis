RECOVERAI - ComfyUI Inpainting Workflow

This package contains a ComfyUI API-format workflow using standard/core nodes.

Expected model:
    512-inpainting-ema.safetensors

Put it here:
    C:\Users\user\Documents\comfy\ComfyUI\models\checkpoints\

Workflow:
Load Checkpoint
    -> CLIP positive/negative
Load Image
    -> VAE Encode
    -> Set Latent Noise Mask
    -> KSampler
    -> VAE Decode
    -> Save Image

Mask meaning:
    WHITE = region to regenerate
    BLACK = region to preserve

Recommended:
    steps = 20
    cfg = 7
    sampler = euler
    scheduler = normal
    denoise = 0.75

FORENSIC WARNING:
The generated image is an AI-INFERRED RECONSTRUCTION — NOT VERIFIED ORIGINAL DATA.
Do not present generated pixels as recovered original bytes.
Keep the original corrupted evidence unchanged and preserve its hash.
